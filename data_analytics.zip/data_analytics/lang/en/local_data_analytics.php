<?php

$string['pluginname'] = 'Data Analytics';
$string['taskname'] = 'local_data_analytics';
