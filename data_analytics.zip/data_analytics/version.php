<?php

$plugin->component = 'local_data_analytics'; // plugin folder name
$plugin->version = 2023030606; // plugin version (YYYYMMDDXX)
$plugin->requires = 2019051100; // Moodle version required
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0.0'; // release name


?>